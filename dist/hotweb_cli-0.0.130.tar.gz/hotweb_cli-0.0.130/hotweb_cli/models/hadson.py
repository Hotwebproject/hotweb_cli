
from hotweb.models.models import Models
model = Models()
model.init({'fjjf': 'aaa'})
def hadson():
    {'fjjf': 'aaa'}
    