
from hotweb.models.models import Models
model = Models()
model.init({'jfjfj': 'kfk'})
def testd():
    {'jfjfj': 'kfk'}
    