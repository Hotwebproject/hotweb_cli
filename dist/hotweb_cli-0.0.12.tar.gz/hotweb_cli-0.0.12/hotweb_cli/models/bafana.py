
from hotweb.models.models import Models
model = Models()
model.init({'jdjdj': 'jest'})
def bafana():
    {'jdjdj': 'jest'}
    