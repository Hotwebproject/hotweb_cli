# migrations skeleton
def up(queryInterface,DataTypes):
    pass

def down(queryInterface,DataTypes):
    pass