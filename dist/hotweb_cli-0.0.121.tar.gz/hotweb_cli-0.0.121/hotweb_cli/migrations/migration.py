# migrations skeleton
def up(queryInterface,DataTypes):
    pass

def down(queryInterface,DataTypes):
    pass

"""
TO HANDLE MIGRATIONS
<---------------------------------------------->
import the up function from the migration file and pass the required two args then call
the cunction ------------------->
--->
"""