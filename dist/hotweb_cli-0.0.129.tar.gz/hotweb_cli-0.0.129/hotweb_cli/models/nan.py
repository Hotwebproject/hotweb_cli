
from hotweb.models.models import Models
model = Models()
model.init({'jdjjd': 'djdj'})
def nan():
    {'jdjjd': 'djdj'}
    