
from hotweb.models.models import Models
model = Models()
model.init({'jfjfj': 'jdjj'})
def haduser():
    {'jfjfj': 'jdjj'}
    