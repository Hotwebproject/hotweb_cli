class MissingArgs(Exception):
    pass